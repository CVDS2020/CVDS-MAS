package rtp

import (
	"net"
	"sync/atomic"
)

type TCPStream struct {
	channel *TCPChannel
	handler atomic.Pointer[Handler]
	addr    atomic.Pointer[net.TCPAddr]
	ssrc    atomic.Int64
}

func (s *TCPStream) Handler() Handler {
	return *s.handler.Load()
}

func (s *TCPStream) SetHandler(handler Handler) Stream {
	s.handler.Store(&handler)
	return s
}

func (s *TCPStream) SSRC() int64 {
	return s.ssrc.Load()
}

func (s *TCPStream) LocalAddr() net.Addr {
	return s.channel.Addr()
}

func (s *TCPStream) RemoteAddr() net.Addr {
	return s.addr.Load()
}

func (s *TCPStream) SetRemoteAddr(addr net.Addr) {
	var tAddr *net.TCPAddr
	switch rAddr := addr.(type) {
	case *net.UDPAddr:
		tAddr = (*net.TCPAddr)(rAddr)
	case *net.TCPAddr:
		tAddr = rAddr
	default:
		return
	}
	s.addr.Store(tAddr)
}

func (s *TCPStream) Send(layer *Layer) error {
	//TODO implement me
	panic("implement me")
}

func (s *TCPStream) Close() {
	//TODO implement me
	panic("implement me")
}

func (s *TCPStream) HandleRTPPacket(stream Stream, packet *Packet) {
	//TODO implement me
	panic("implement me")
}

func (s *TCPStream) OnRTPChannelClose(stream Stream) {
	//TODO implement me
	panic("implement me")
}
