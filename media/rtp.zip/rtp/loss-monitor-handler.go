package rtp

import "gitee.com/sy_183/common/log"

type LossMonitorHandler struct {
	handler Handler
	seq     uint16
	init    bool
}

func NewLossMonitorHandler(handler Handler) *LossMonitorHandler {
	return &LossMonitorHandler{handler: handler}
}

func (h *LossMonitorHandler) HandleRTPPacket(stream Stream, packet *Packet) {
	if !h.init {
		h.init = true
		h.seq = packet.SequenceNumber()
		h.handler.HandleRTPPacket(stream, packet)
		return
	}
	if diff := packet.SequenceNumber() - h.seq; diff != 1 {
		go Logger().Warn("rtp loss packet", log.Uint16("loss packet", diff-1))
	}
	h.seq = packet.SequenceNumber()
	h.handler.HandleRTPPacket(stream, packet)
}

func (h *LossMonitorHandler) OnRTPChannelClose(stream Stream) {
	h.handler.OnRTPChannelClose(stream)
}
