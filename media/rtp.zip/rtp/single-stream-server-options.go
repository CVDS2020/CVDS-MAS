package rtp

func WithHandler(handler Handler) ServerOption {
	return serverOptionFunc(func(s Server) any {
		if ss, is := s.(*SingleStreamServer); is {
			ss.SetHandler(handler)
		}
		return nil
	})
}
