package main

import (
	"gitee.com/sy_183/common/assert"
	"gitee.com/sy_183/common/log"
	svc "gitee.com/sy_183/common/system/service"
	"gitee.com/sy_183/cvds-mas/media/rtp"
	"gitee.com/sy_183/cvds-mas/transport/udp"
	"net"
	"os"
)

var logger = assert.Must(log.Config{
	Encoder: log.NewConsoleEncoder(log.ConsoleEncoderConfig{
		DisableTime:     true,
		DisableCaller:   true,
		DisableFunction: true,
		EncodeLevel:     log.CapitalColorLevelEncoder,
	}),
}.Build())

func main() {
	s := udp.NewServer(assert.Must(net.ResolveUDPAddr("udp", "0.0.0.0:6901")), func(s *udp.Server, packet *udp.Packet) bool {
		defer packet.Release()
		layer := new(rtp.Layer)
		if err := layer.Unmarshal(packet.Data.Data); err != nil {
			go logger.ErrorWith("parse rtp packet error", err)
			return false
		}
		go logger.Info(layer.String())
		return true
	})
	os.Exit(svc.New("udp-test", s).Run())
}
