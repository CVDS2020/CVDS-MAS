package rtp

import (
	"gitee.com/sy_183/common/flag"
	"gitee.com/sy_183/common/lifecycle"
	"sync"
	"testing"
	"time"
)

type TestLifecycle struct {
	lifecycle.Lifecycle
}

func NewTestLifecycle() *TestLifecycle {
	l := new(TestLifecycle)
	_, l.Lifecycle = lifecycle.New("", lifecycle.StartFn(l.start), lifecycle.Context(l.run))
	return l
}

func (l *TestLifecycle) start() error {
	time.Sleep(time.Second)
	return nil
}

func (l *TestLifecycle) run(interrupter chan struct{}) error {
	<-interrupter
	time.Sleep(time.Second)
	return nil
}

type lifecycleWrapper struct {
	l     *TestLifecycle
	state int
	mu    sync.Mutex
}

func (l *lifecycleWrapper) alloc() bool {
	l.mu.Lock()
	if !flag.TestFlag(l.state, serverStateStopped) {
		l.mu.Unlock()
		return false
	}
	// lifecycle must be stopped
	flag.SwapFlagMask(l.state, serverStateStop, serverStateStarting)
	l.mu.Unlock()

	err := l.l.Start()

	l.mu.Lock() // second lock
	flag.UnmaskFlag(l.state, serverStateStarting)
	if err == nil {
		// lifecycle not stopped
		flag.UnmaskFlag(l.state, serverStateStopped)
		if flag.TestFlag(l.state, serverStateStop) {
			// lifecycle mask stop flag, do stop
			flag.TestFlag(l.state, serverStateStopping)
			l.l.Close(nil)
			go func() {
				<-l.l.AddClosedFuture(nil)
				l.mu.Lock()
				flag.SwapFlagMask(l.state, serverStateStopping, serverStateStopped)
				l.mu.Unlock()
			}()
			l.mu.Unlock() // second unlock
			return false
		}
		l.mu.Unlock()
		return true
	}
	// lifecycle start error
	l.mu.Unlock()
	return false
}

func (l *lifecycleWrapper) free() {
	l.mu.Lock()
	if flag.TestFlag(l.state, serverStateStop) {
		l.mu.Unlock()
		return
	}
	flag.MaskFlag(l.state, serverStateStop)
	if flag.TestFlag(l.state, serverStateStarting) {
		l.mu.Unlock()
		<-l.l.AddRunningFuture(nil)
		return
	} else {
		l.l.Close(nil)
		go func() {
			<-l.l.AddClosedFuture(nil)
			l.mu.Lock()
			flag.SwapFlagMask(l.state, serverStateStopping, serverStateStopped)
			l.mu.Unlock()
		}()
	}
	l.mu.Unlock()
}

type lifecycleWrappers struct {
	lifecycle.Lifecycle
	ls []*lifecycleWrapper
}

func NewLifecycleWrappers(size int) *lifecycleWrappers {
	ls := new(lifecycleWrappers)
	for i := 0; i < size; i++ {
		ls.ls = append(ls.ls, &lifecycleWrapper{l: NewTestLifecycle(), state: serverStateStop | serverStateStopped})
	}
	return ls
}

func (l *lifecycleWrappers) run(interrupter chan struct{}) error {
	<-interrupter
	var runningFutures []chan error
	var startingLifecycles []*lifecycleWrapper
	var closedFutures []chan error
	for _, sl := range l.ls {
		sl.mu.Lock()
		firstStop := flag.TestFlag(sl.state, serverStateStop)
		if firstStop {
			flag.MaskFlag(sl.state, serverStateStop)
		}
		if flag.TestFlag(sl.state, serverStateStopped) {
			continue
		}
		if flag.TestFlag(sl.state, serverStateStarting) {
			runningFutures = append(runningFutures, sl.l.AddRunningFuture(nil))
		} else {
			if firstStop {
				sl.l.Close(nil)
			}
			closedFutures = append(closedFutures, sl.l.AddClosedFuture(nil))
		}
		sl.mu.Unlock()
	}
	for i, future := range runningFutures {
		if err := <-future; err == nil {
			closedFutures = append(closedFutures, startingLifecycles[i].l.AddClosedFuture(nil))
		}
	}
	for _, future := range closedFutures {
		<-future
	}
	return nil
}

func TestLifecycleAlloc(t *testing.T) {
	//ls := NewLifecycleWrappers(10)
}
