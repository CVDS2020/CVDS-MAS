package rtp

type Handler interface {
	HandleRTPPacket(stream Stream, packet *Packet)
	OnRTPChannelClose(stream Stream)
}

type HandlerFunc struct {
	HandleRTPPacketFn   func(stream Stream, packet *Packet)
	OnRTPChannelCloseFn func(stream Stream)
}

func (h HandlerFunc) HandleRTPPacket(stream Stream, packet *Packet) {
	if handleRTPPacketFn := h.HandleRTPPacketFn; handleRTPPacketFn != nil {
		handleRTPPacketFn(stream, packet)
	} else {
		packet.Release()
	}
}

func (h HandlerFunc) OnRTPChannelClose(stream Stream) {
	if onRTPChannelCloseFn := h.OnRTPChannelCloseFn; onRTPChannelCloseFn != nil {
		onRTPChannelCloseFn(stream)
	}
}
