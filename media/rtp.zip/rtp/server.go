package rtp

import (
	"gitee.com/sy_183/common/lifecycle"
	"gitee.com/sy_183/cvds-mas/transport/udp"
	"net"
)

type Server interface {
	lifecycle.Lifecycle

	Name() string

	UDPServer() *udp.Server

	UDPAddr() *net.UDPAddr

	ErrorHandler() func(s Server, err error)

	SetErrorHandler(handler func(s Server, err error)) Server

	OnStartedCallback() func(s Server)

	OnStarted(callback func(s Server)) Server

	OnClosedCallback() func(s Server, err error)

	OnClosed(callback func(s Server, err error)) Server

	SendTo(layer *Layer, addr *net.UDPAddr) error
}

type serverPrivate interface {
	Server

	start() error

	run() error

	close() error

	queuePacket(us *udp.Server, upk *udp.Packet) bool

	handlePacket(upk *udp.Packet) error

	handleError(err error)
}
