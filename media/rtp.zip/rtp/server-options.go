package rtp

import (
	"gitee.com/sy_183/common/pool"
	"gitee.com/sy_183/cvds-mas/transport/udp"
)

// An ServerOption configures a Server.
type ServerOption interface {
	apply(s Server) any
}

// serverOptionFunc wraps a func, so it satisfies the ServerOption interface.
type serverOptionFunc func(s Server) any

func (f serverOptionFunc) apply(s Server) any {
	return f(s)
}

type NameOption string

func WithName(name string) ServerOption {
	return serverOptionFunc(func(s Server) any {
		return NameOption(name)
	})
}

func WithErrorHandler(handler func(s Server, err error)) ServerOption {
	return serverOptionFunc(func(s Server) any {
		s.SetErrorHandler(handler)
		return nil
	})
}

func OnStarted(callback func(s Server)) ServerOption {
	return serverOptionFunc(func(s Server) any {
		s.OnStarted(callback)
		return nil
	})
}

func OnClosed(callback func(s Server, err error)) ServerOption {
	return serverOptionFunc(func(s Server) any {
		s.OnClosed(callback)
		return nil
	})
}

func WithUDPOptions(options ...udp.Option) ServerOption {
	return serverOptionFunc(func(s Server) any {
		return options
	})
}

func WithQueueSize(size uint) ServerOption {
	type queueSizeSetter interface {
		setQueue(chan *udp.Packet)
	}
	return serverOptionFunc(func(s Server) any {
		if setter, is := s.(queueSizeSetter); is {
			setter.setQueue(make(chan *udp.Packet, size))
		}
		return nil
	})
}

func WithLayerPool(p *pool.Pool[*Layer]) ServerOption {
	type layerPoolSetter interface {
		setLayerPool(p *pool.Pool[*Layer])
	}
	return serverOptionFunc(func(s Server) any {
		if setter, is := s.(layerPoolSetter); is {
			setter.setLayerPool(p)
		}
		return nil
	})
}
