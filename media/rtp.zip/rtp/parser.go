package rtp

import "encoding/binary"

type TCPHeader struct {
	ID      byte
	Channel uint8
	Length  uint16
}

type Parser struct {
	layer  *Layer
	header []byte
	need   int
	cache  [][]byte
}

func (p *Parser) Set(layer *Layer) {
	p.layer = layer
	p.header = p.header[:0]
	p.need = 0
	p.cache = p.cache[:0]
}

func (p *Parser) Parse(buf []byte) (header TCPHeader, layer *Layer, remain []byte, err error) {
	if len(p.header) < 4 {
		hn := 4 - len(p.header)
		if len(buf) >= hn {
			p.header = append(p.header, buf[:hn]...)
			buf = buf[hn:]
			p.need = int(binary.BigEndian.Uint16(p.header[2:]))
		} else {
			p.header = append(p.header, buf...)
			return
		}
	}
	if len(buf) == 0 {
		return
	}
	if len(buf) >= p.need {
		p.cache = append(p.cache, buf[:p.need])
		remain = buf[p.need:]
		err = p.layer.UnmarshalChunks(p.cache)
		header = TCPHeader{
			ID:      p.header[0],
			Channel: p.header[1],
			Length:  binary.BigEndian.Uint16(p.header[2:]),
		}
		layer = p.layer
		p.Set(nil)
		return
	}
	p.cache = append(p.cache, buf)
	p.need -= len(buf)
	return
}
