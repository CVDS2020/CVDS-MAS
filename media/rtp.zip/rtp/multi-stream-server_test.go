package rtp

import (
	"gitee.com/sy_183/common/assert"
	"gitee.com/sy_183/common/unit"
	"gitee.com/sy_183/cvds-mas/transport/udp"
	"net"
	"testing"
)

func TestServer(t *testing.T) {
	NewMultiStreamServer(assert.Must(net.ResolveUDPAddr("udp", "0.0.0.0:5004")),
		WithNewChannelHandler(func(s *MultiStreamServer, packet *Packet) bool {
			s.Stream(packet.Upk.UDPAddr, int64(packet.SSRC()), HandlerFunc{HandleRTPPacketFn: func(stream Stream, packet *Packet) {
				logger.Logger().Info(packet.String())
			}})
			return true
		}),
		WithErrorHandler(func(s Server, err error) {
			Logger().ErrorWith("parse rtp packet error", err)
		}),
		WithUDPOptions(udp.WithName("rtp server"), udp.WithReadBuffer(4*unit.MeBiByte)),
	)
}
