package rtp

func WithNewChannelHandler(handler func(s *MultiStreamServer, packet *Packet) bool) ServerOption {
	return serverOptionFunc(func(s Server) any {
		if ms, is := s.(*MultiStreamServer); is {
			ms.SetNewChannelHandler(handler)
		}
		return nil
	})
}
