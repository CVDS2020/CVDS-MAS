package rtp

import (
	"net"
	"sync/atomic"
)

type SingleStream struct {
	server  *SingleStreamServer
	handler atomic.Pointer[Handler]
	addr    atomic.Pointer[net.UDPAddr]
	ssrc    atomic.Int64
}

func (s *SingleStream) Handler() Handler {
	return *s.handler.Load()
}

func (s *SingleStream) SetHandler(handler Handler) Stream {
	s.handler.Store(&handler)
	return s
}

func (s *SingleStream) SSRC() int64 {
	return s.ssrc.Load()
}

func (s *SingleStream) LocalAddr() net.Addr {
	return s.server.UDPAddr()
}

func (s *SingleStream) RemoteAddr() net.Addr {
	return s.addr.Load()
}

func (s *SingleStream) SetRemoteAddr(addr net.Addr) {
	var uAddr *net.UDPAddr
	switch rAddr := addr.(type) {
	case *net.TCPAddr:
		uAddr = (*net.UDPAddr)(rAddr)
	case *net.UDPAddr:
		uAddr = rAddr
	default:
		return
	}
	s.addr.Store(uAddr)
}

func (s *SingleStream) Send(layer *Layer) error {
	if addr := s.addr.Load(); addr != nil {
		return s.server.SendTo(layer, addr)
	}
	return nil
}

func (s *SingleStream) Close() {
	s.SetHandler(HandlerFunc{})
}

func (s *SingleStream) HandleRTPPacket(stream Stream, packet *Packet) {
	s.Handler().HandleRTPPacket(stream, packet)
}

func (s *SingleStream) OnRTPChannelClose(stream Stream) {
	s.Handler().OnRTPChannelClose(stream)
}
