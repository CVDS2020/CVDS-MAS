package rtp

import (
	"gitee.com/sy_183/common/pool"
)

type FrameHandler interface {
	HandleRTPFrame(stream Stream, frame *Frame)
	OnRTPChannelClose(stream Stream)
}

type FrameHandlerFunc struct {
	HandleRTPFrameFn    func(stream Stream, frame *Frame)
	OnRTPChannelCloseFn func(stream Stream)
}

func (h FrameHandlerFunc) HandleRTPFrame(stream Stream, frame *Frame) {
	if handleRTPFrameFn := h.HandleRTPFrameFn; handleRTPFrameFn != nil {
		handleRTPFrameFn(stream, frame)
	}
}

func (h FrameHandlerFunc) OnRTPChannelClose(stream Stream) {
	if onRTPChannelCloseFn := h.OnRTPChannelCloseFn; onRTPChannelCloseFn != nil {
		onRTPChannelCloseFn(stream)
	}
}

type FrameRTPHandler struct {
	cur          *Frame
	frameHandler FrameHandler
	framePool    *pool.SyncPool[*Frame]
}

func NewFrameRTPHandler(frameHandler FrameHandler) *FrameRTPHandler {
	return &FrameRTPHandler{
		frameHandler: frameHandler,
		framePool: pool.NewPool(func(p *pool.Pool[*Frame]) *Frame {
			return &Frame{
				pool: p,
			}
		}),
	}
}

func (h *FrameRTPHandler) HandleRTPPacket(stream Stream, packet *Packet) {
	defer packet.Release()
	if h.cur != nil && packet.Timestamp() != h.cur.Timestamp {
		h.frameHandler.HandleRTPFrame(stream, h.cur)
		h.cur = nil
	}
	if h.cur == nil {
		h.cur = h.framePool.Get().Use()
	}
	h.cur.Append(packet)
}

func (h *FrameRTPHandler) OnRTPChannelClose(stream Stream) {
	if h.cur != nil && len(h.cur.Packets) != 0 {
		h.frameHandler.HandleRTPFrame(stream, h.cur)
	}
	h.frameHandler.OnRTPChannelClose(stream)
}
