package rtp

import (
	"gitee.com/sy_183/common/pool"
	"gitee.com/sy_183/cvds-mas/transport/udp"
	"sync/atomic"
	"time"
)

type Packet struct {
	*Layer
	Upk    *udp.Packet
	Time   time.Time
	chunks []*Data
	ref    int64
	pool   *pool.SyncPool[*Layer]
}

type PacketSetter func(packet *Packet)

func PacketUDP(upk *udp.Packet) PacketSetter {
	return func(packet *Packet) {
		packet.Upk = upk
	}
}

func PacketTime(time time.Time) PacketSetter {
	return func(packet *Packet) {
		packet.Time = time
	}
}

func PacketChunks(chunks []*Data) PacketSetter {
	return func(packet *Packet) {
		packet.chunks = chunks
	}
}

func PacketLayerPool(pool *pool.Pool[*Layer]) PacketSetter {
	return func(packet *Packet) {
		packet.pool = pool
	}
}

func NewPacket(layer *Layer, setters ...PacketSetter) *Packet {
	p := &Packet{
		Layer: layer,
		ref:   1,
	}
	for _, setter := range setters {
		setter(p)
	}
	return p
}

func (p *Packet) Release() {
	if c := atomic.AddInt64(&p.ref, -1); c == 0 {
		if p.Upk != nil {
			p.Upk.Release()
		}
		for _, chunk := range p.chunks {
			chunk.Release()
		}
		if p.pool != nil {
			p.pool.Put(p.Layer)
		}
	} else if c < 0 {
		Logger().Fatal("rtp packet wrapper repeat release")
	}
}

func (p *Packet) AddRef() {
	if atomic.AddInt64(&p.ref, 1) <= 0 {
		Logger().Fatal("invalid rtp packet wrapper reference count")
	}
}

func (p *Packet) Use() *Packet {
	p.AddRef()
	return p
}
