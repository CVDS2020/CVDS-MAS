package rtp

import (
	"gitee.com/sy_183/cvds-mas/transport/udp"
	"net"
	"sync/atomic"
	"time"
)

type SingleStreamServer struct {
	abstractServer
	stream  atomic.Pointer[SingleStream]
	handler atomic.Pointer[Handler]
	addr    atomic.Pointer[net.UDPAddr]
	ssrc    atomic.Int64
}

func NewSingleStreamServer(addr *net.UDPAddr, options ...ServerOption) *SingleStreamServer {
	s := new(SingleStreamServer)
	s.init(addr, nil, options...)
	return s
}

func NewSingleStreamServerWithUDP(udpServer *udp.Server, options ...ServerOption) *SingleStreamServer {
	s := new(SingleStreamServer)
	s.init(nil, udpServer, options...)
	return s
}

func (s *SingleStreamServer) init(addr *net.UDPAddr, udpServer *udp.Server, options ...ServerOption) {
	s.SetHandler(HandlerFunc{})
	s.ssrc.Store(-1)
	s.OnClosed(nil)
	s.abstractServer.init(s, addr, udpServer, options...)
}

func (s *SingleStreamServer) Handler() Handler {
	return *s.handler.Load()
}

func (s *SingleStreamServer) SetHandler(handler Handler) *SingleStreamServer {
	s.handler.Store(&handler)
	return s
}

func (s *SingleStreamServer) handlePacket(upk *udp.Packet) error {
	layer := s.pool.Get()
	err := layer.Unmarshal(upk.Data.Data)
	if err != nil {
		upk.Release()
		s.pool.Put(layer)
		return err
	}
	if !s.addr.CompareAndSwap(nil, upk.UDPAddr) {
		addr := s.addr.Load()
		if !addr.IP.Equal(upk.UDPAddr.IP) ||
			addr.Port != upk.UDPAddr.Port ||
			addr.Zone != upk.UDPAddr.Zone {
			// packet addr not matched, dropped
			upk.Release()
			s.pool.Put(layer)
			return nil
		}
	}
	if !s.ssrc.CompareAndSwap(-1, int64(layer.SSRC())) {
		ssrc := s.ssrc.Load()
		if ssrc != int64(layer.SSRC()) {
			upk.Release()
			s.pool.Put(layer)
			return nil
		}
	}
	packet := NewPacket(layer, PacketUDP(upk), PacketTime(time.Now()), PacketLayerPool(s.pool))
	if stream := s.stream.Load(); stream != nil {
		stream.HandleRTPPacket(stream, packet)
	}
	return nil
}

func (s *SingleStreamServer) OnClosed(callback func(s Server, err error)) Server {
	s.abstractServer.OnClosed(func(ss Server, err error) {
		s.OnRTPChannelClose(s)
		if callback != nil {
			callback(ss, err)
		}
	})
	return s
}

func (s *SingleStreamServer) Server() Server {
	return s
}

func (s *SingleStreamServer) SSRC() int64 {
	return s.ssrc.Load()
}

func (s *SingleStreamServer) RemoteAddr() net.Addr {
	return s.addr.Load()
}

func (s *SingleStreamServer) Send(layer *Layer) error {
	if addr := s.addr.Load(); addr != nil {
		return s.SendTo(layer, addr)
	}
	return nil
}

func (s *SingleStreamServer) CloseStream() {

}

func (s *SingleStreamServer) HandleRTPPacket(stream Stream, packet *Packet) {
	s.Handler().HandleRTPPacket(stream, packet)
}

func (s *SingleStreamServer) OnRTPChannelClose(stream Stream) {
	s.Handler().OnRTPChannelClose(stream)
}
