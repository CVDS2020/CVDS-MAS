package channel

import (
	"errors"
	"gitee.com/sy_183/common/def"
	"gitee.com/sy_183/common/lifecycle"
	"gitee.com/sy_183/common/lock"
	"gitee.com/sy_183/common/log"
	"gitee.com/sy_183/cvds-mas/media"
	mediaRtp "gitee.com/sy_183/cvds-mas/media/rtp"
	"gitee.com/sy_183/cvds-mas/storage"
	"gitee.com/sy_183/rtp/frame"
	rtpServer "gitee.com/sy_183/rtp/server"
	"io"
	"net"
	"strings"
	"sync"
	"sync/atomic"
	"time"
)

type WriteRtpFrame struct {
	*frame.Frame
	mediaType   uint32
	storageType uint32
}

func (f WriteRtpFrame) WriteTo(w io.Writer) (n int64, err error) {
	return frame.FullLayerWriter{Layer: f.Layer}.WriteTo(w)
}

func (f WriteRtpFrame) Size() uint {
	return frame.FullLayerWriter{Layer: f.Layer}.Size()
}

func (f WriteRtpFrame) MediaType() uint32 {
	return f.mediaType
}

func (f WriteRtpFrame) StorageType() uint32 {
	return f.storageType
}

type WriteRawFrame struct {
	*frame.Frame
	mediaType   uint32
	storageType uint32
}

func (f WriteRawFrame) WriteTo(w io.Writer) (n int64, err error) {
	return frame.PayloadLayerWriter{Layer: f.Layer}.WriteTo(w)
}

func (f WriteRawFrame) Size() uint {
	return frame.PayloadLayerWriter{Layer: f.Layer}.Size()
}

func (f WriteRawFrame) MediaType() uint32 {
	return f.mediaType
}

func (f WriteRawFrame) StorageType() uint32 {
	return f.storageType
}

type RTPPlayerCloseCallback func(player *RTPPlayer, channel *Channel)

type RTPPlayer struct {
	lifecycle.Lifecycle
	runner *lifecycle.DefaultLifecycle

	channel   *Channel
	transport string
	timeout   time.Duration

	rtpManager *rtpServer.Manager
	rtpServer  rtpServer.Server
	stream     atomic.Pointer[rtpServer.Stream]

	localIP    net.IP
	localPort  int
	remoteAddr atomic.Pointer[net.TCPAddr]
	ssrc       atomic.Int64
	mediaMap   atomic.Pointer[[]*media.MediaType]
	mu         sync.Mutex

	log.AtomicLogger
}

func NewRTPPlayer(channel *Channel, transport string, timeout time.Duration) (*RTPPlayer, error) {
	timeout = def.SetDefault(timeout, time.Second*5)
	if timeout < time.Second {
		timeout = time.Second
	}
	p := &RTPPlayer{
		channel: channel,
		timeout: timeout,
	}
	p.ssrc.Store(-1)

	switch strings.ToLower(transport) {
	case "udp":
		p.transport = "udp"
		rtpManager := mediaRtp.GetManager()
		server := rtpManager.Alloc()
		if server == nil {
			channel.Logger().Error(AllocRTPServerFailed.Error())
			return nil, AllocRTPServerFailed
		}
		p.rtpManager = rtpManager
		p.rtpServer = server
		addr := p.rtpServer.Addr().(*net.UDPAddr)
		if ipv4 := addr.IP.To4(); ipv4 != nil {
			p.localIP = ipv4
		} else {
			p.localIP = addr.IP
		}
		p.localPort = addr.Port
	default:
		p.transport = "tcp"
		p.rtpServer = mediaRtp.GetTCPServer()
		addr := p.rtpServer.Addr().(*net.TCPAddr)
		if ipv4 := addr.IP.To4(); ipv4 != nil {
			p.localIP = ipv4
		} else {
			p.localIP = addr.IP
		}
		p.localPort = addr.Port
	}

	p.SetLogger(channel.Logger().Named(p.DisplayName()))
	p.runner = lifecycle.NewWithInterruptedRun(nil, p.run)
	p.Lifecycle = p.runner
	return p, nil
}

func (p *RTPPlayer) DisplayName() string {
	return p.channel.RTPPlayerDisplayName()
}

func (p *RTPPlayer) Transport() string {
	return p.transport
}

func (p *RTPPlayer) Timeout() time.Duration {
	return p.timeout
}

func (p *RTPPlayer) LocalIP() net.IP {
	return p.localIP
}

func (p *RTPPlayer) LocalPort() int {
	return p.localPort
}

func (p *RTPPlayer) RemoteIPPort() (net.IP, int) {
	remoteTCPAddr := p.remoteAddr.Load()
	if remoteTCPAddr == nil {
		return nil, 0
	}
	return remoteTCPAddr.IP, remoteTCPAddr.Port
}

func (p *RTPPlayer) SSRC() int64 {
	return p.ssrc.Load()
}

func (p *RTPPlayer) Info() map[string]any {
	info := map[string]any{
		"transport": p.Transport(),
		"timeout":   p.Timeout(),
		"localIp":   p.LocalIP(),
		"localPort": p.LocalPort(),
	}
	if ip, port := p.RemoteIPPort(); ip != nil {
		info["remoteIp"] = ip
		info["remotePort"] = port
	}
	if ssrc := p.SSRC(); ssrc >= 0 {
		info["ssrc"] = ssrc
	}
	if mediaMap := p.MediaMap(); mediaMap != nil {
		rtpMap := make(map[uint8]string)
		for id, mediaType := range mediaMap {
			if mediaType != nil {
				rtpMap[uint8(id)] = mediaType.UpperName
			}
		}
		info["rtpMap"] = rtpMap
	}
	return info
}

func (p *RTPPlayer) getStream() rtpServer.Stream {
	if stream := p.stream.Load(); stream != nil {
		return *stream
	}
	return nil
}

func (p *RTPPlayer) run(_ lifecycle.Lifecycle, interrupter chan struct{}) error {
	defer func() {
		if stream := p.getStream(); stream != nil {
			stream.Close()
		}
		if p.rtpManager != nil {
			p.rtpManager.Free(p.rtpServer)
		}
	}()
	<-interrupter
	return nil
}

func (p *RTPPlayer) storageFrameRaw(f *frame.Frame, mediaType *media.MediaType) {
	if storageChannel := p.channel.loadEnabledStorageChannel(); storageChannel != nil {
		storageChannel.Write(WriteRawFrame{
			Frame:       f,
			mediaType:   mediaType.ID,
			storageType: mediaType.ID,
		})
		return
	}
}

func (p *RTPPlayer) storageFrameRtp(f *frame.Frame, mediaType *media.MediaType) {
	if storageChannel := p.channel.loadEnabledStorageChannel(); storageChannel != nil {
		storageChannel.Write(WriteRtpFrame{
			Frame:       f,
			mediaType:   mediaType.ID,
			storageType: storage.StorageTypeRTP.ID,
		})
		return
	}
}

func (p *RTPPlayer) handleFrame(stream rtpServer.Stream, f *frame.Frame) {
	var mediaType *media.MediaType
	if mediaMap := p.MediaMap(); mediaMap != nil {
		mediaType = mediaMap[f.PayloadType]
	}
	if mediaType == nil {
		mediaType = media.GetMediaType(uint32(f.PayloadType))
	}
	if mediaType != nil && mediaType.ID < 128 {
		if uint8(mediaType.ID) != f.PayloadType {
			for _, layer := range f.RTPLayers {
				layer.SetPayloadType(uint8(mediaType.ID))
			}
			f.PayloadType = uint8(mediaType.ID)
		}
		switch p.channel.StorageType() {
		case "rtp":
			p.storageFrameRtp(f.Use(), mediaType)
		case "raw":
			p.storageFrameRaw(f.Use(), mediaType)
		default:
			p.storageFrameRtp(f.Use(), mediaType)
		}
	}
	f.Release()
}

func (p *RTPPlayer) onStreamClosed(stream rtpServer.Stream) {
	stream.Logger().Info("RTP流已经关闭")
	lock.LockDo(&p.mu, func() {
		p.stream.Store(nil)
		if storageChannel := p.channel.loadEnabledStorageChannel(); storageChannel != nil {
			storageChannel.Sync()
		}
		p.Close(nil)
	})
}

func (p *RTPPlayer) MediaMap() []*media.MediaType {
	if mediaMap := p.mediaMap.Load(); mediaMap != nil {
		return *mediaMap
	}
	return nil
}

func (p *RTPPlayer) Setup(rtpMap map[uint8]string, remoteIP net.IP, remotePort int, ssrc int64, once bool) error {
	return lock.RLockGet(p.runner, func() error {
		if !p.runner.Running() {
			return p.Logger().ErrorWith("设置RTP拉流参数失败", lifecycle.NewStateNotRunningError(p.DisplayName()))
		}

		mediaMap := make([]*media.MediaType, 128)
		for id, name := range rtpMap {
			if id < 128 {
				mediaMap[id] = media.ParseMediaType(name)
			}
		}

		if ipv4 := remoteIP.To4(); ipv4 != nil {
			remoteIP = ipv4
		}
		var remoteAddr net.Addr
		remoteTCPAddr := &net.TCPAddr{IP: remoteIP, Port: remotePort}
		switch p.transport {
		case "tcp":
			remoteAddr = remoteTCPAddr
		case "udp":
			remoteAddr = (*net.UDPAddr)(remoteTCPAddr)
		}

		return lock.LockGet(&p.mu, func() error {
			//now := time.Now()
			if stream := p.getStream(); stream != nil {
				if once {
					return nil
				}
				//p.setupTime.Store(&now)
				stream.SetRemoteAddr(remoteAddr)
				stream.SetSSRC(ssrc)
			} else {
				p.mediaMap.Store(&mediaMap)
				stream, _ = p.rtpServer.Stream(remoteAddr, ssrc, frame.NewFrameRTPHandler(frame.FrameHandlerFunc{
					HandleFrameFn:    p.handleFrame,
					OnStreamClosedFn: p.onStreamClosed,
				}), rtpServer.WithTimeout(p.timeout), rtpServer.WithOnStreamTimeout(func(rtpServer.Stream) {
					stream.Logger().Warn("RTP流超时, 关闭拉流")
				}))
				if stream == nil {
					p.mediaMap.Store(nil)
					return p.Logger().ErrorWith("设置RTP拉流参数失败", errors.New("RTP服务申请流失败"))
				}
				//p.setupTime.Store(&now)
				p.stream.Store(&stream)
			}

			p.remoteAddr.Store(remoteTCPAddr)
			p.ssrc.Store(ssrc)

			fields := []log.Field{log.String("对端IP地址", remoteIP.String()), log.Int("对端端口", remotePort)}
			if remoteAddr != nil {
				fields = append(fields, log.String("对端IP地址", remoteIP.String()), log.Int("对端端口", remotePort))
			}
			if ssrc >= 0 {
				fields = append(fields, log.Int64("SSRC", ssrc))
			}
			if rtpMap != nil {
				fields = append(fields, log.Reflect("RtpMap", rtpMap))
			}
			p.Logger().Info("设置RTP拉流参数成功", fields...)

			return nil
		})
	})
}
