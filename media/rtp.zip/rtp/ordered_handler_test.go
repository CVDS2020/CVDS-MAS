package rtp

import (
	"fmt"
	"testing"
)

func TestOrderedHandler(t *testing.T) {
	h := NewOrderedHandler(StreamHandlerFunc{
		HandleRTPPacketFn: func(s *MultiStreamServer, stream *SubStream, packet *Packet) {
			fmt.Println(packet.String())
		},
	}, 8)
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 1,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 2,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 4,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 3,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 5,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 8,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 7,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 6,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 9,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 9,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 8,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 12,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 10,
	})))
	h.HandleRTPPacket(nil, nil, NewPacket(BuildLayer(&LayerConfig{
		PayloadType:    96,
		SequenceNumber: 11,
	})))
	h.OnRTPChannelClose(nil, nil)
}
