package rtp

import (
	"gitee.com/sy_183/common/def"
	"gitee.com/sy_183/common/flag"
	"gitee.com/sy_183/common/lifecycle"
	"gitee.com/sy_183/common/timer"
	"time"
)

type RetryableServer struct {
	lifecycle.Lifecycle
	server        Server
	retryInterval time.Duration
}

func NewRetryableServer(s Server, retryInterval time.Duration) *RetryableServer {
	rs := &RetryableServer{
		server:        s,
		retryInterval: retryInterval,
	}
	rs.retryInterval = def.SetDefault(rs.retryInterval, time.Second)
	_, rs.Lifecycle = lifecycle.New(s.Name(), lifecycle.Context(rs.run))
	return rs
}

func (s *RetryableServer) start() error {
	return s.server.Start()
}

func (s *RetryableServer) run(interrupter chan struct{}) error {
	var state int
	var startedChan = make(chan error, 1)
	var closedChan = make(chan error, 1)
	var startRetryTimer = timer.NewTimer(make(chan struct{}, 1))

	s.server.AddClosedFuture(closedChan)
	for {
		select {
		case <-startRetryTimer.C:
			// must be stopped, must not be starting
			if !flag.TestFlag(state, retryableStateInterrupt) {
				flag.MaskFlag(state, retryableStateStarting)
				go func() {
					startedChan <- s.server.Start()
				}()
			} else if flag.TestFlag(state, retryableStateInterrupt) {
				return nil
			}
		case err := <-startedChan:
			flag.UnmaskFlag(state, retryableStateStarting)
			if err == nil {
				flag.UnmaskFlag(state, retryableStateStopped)
				s.server.AddClosedFuture(closedChan)
			}
			if !flag.TestFlag(state, retryableStateInterrupt) {
				if err != nil {
					startRetryTimer.After(s.retryInterval)
				}
			} else {
				if flag.TestFlag(state, retryableStateStopped) {
					return nil
				} else {
					s.server.Close(nil)
				}
			}
		case <-closedChan:
			// must not be stopped or starting
			flag.MaskFlag(state, retryableStateStopped)
			if flag.TestFlag(state, retryableStateInterrupt) {
				return nil
			}
			startRetryTimer.After(s.retryInterval)
		case <-interrupter:
			flag.MaskFlag(state, retryableStateInterrupt)
			if flag.TestFlag(state, retryableStateStopped) {
				return nil
			}
			s.server.Close(nil)
		}
	}
}

func (s *RetryableServer) Server() Server {
	return s.server
}
