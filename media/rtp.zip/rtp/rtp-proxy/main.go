package main

import (
	"gitee.com/sy_183/common/assert"
	"gitee.com/sy_183/common/config"
	"gitee.com/sy_183/common/log"
	svc "gitee.com/sy_183/common/system/service"
	"gitee.com/sy_183/cvds-mas/media/rtp"
	"gitee.com/sy_183/cvds-mas/transport/udp"
	"github.com/spf13/cobra"
	"net"
	"os"
	"time"
)

func init() {
	cobra.MousetrapHelpText = ""
}

var logger = assert.Must(log.Config{
	Encoder: log.NewConsoleEncoder(log.ConsoleEncoderConfig{
		DisableTime:     true,
		DisableCaller:   true,
		DisableFunction: true,
		EncodeLevel:     log.CapitalColorLevelEncoder,
	}),
}.Build())

type Args struct {
	Help        bool
	LocalAddr   string
	RemoteAddr  string
	QueueSize   uint
	ReadBuffer  int
	WriteBuffer int
}

func main() {
	ac := &Args{Help: true}
	config.Handle(ac)

	command := cobra.Command{
		Use:   "rtp-proxy",
		Short: "RTP Proxy Application",
		Long:  "RTP Proxy Application",
		Run: func(cmd *cobra.Command, args []string) {
			ac.Help = false
		},
	}

	command.Flags().StringVarP(&ac.LocalAddr, "local-addr", "l", "0.0.0.0:5004", "rtp server listening local address")
	command.Flags().StringVarP(&ac.RemoteAddr, "remote-addr", "r", "127.0.0.1:5004", "rtp server proxy remote address")
	command.Flags().UintVarP(&ac.QueueSize, "queue-size", "q", 64, "rtp packet queue size")
	command.Flags().IntVar(&ac.ReadBuffer, "read-buffer", 1048576, "udp read buffer size")
	command.Flags().IntVar(&ac.WriteBuffer, "write-buffer", 1048576, "udp write buffer size")

	if err := command.Execute(); err != nil {
		logger.Fatal("parse args error", log.Error(err))
	}

	if ac.Help {
		os.Exit(0)
	}

	localAddr, err := net.ResolveUDPAddr("udp", ac.LocalAddr)
	if err != nil {
		logger.Fatal("resolve local addr error", log.Error(err))
	}

	remoteAddr, err := net.ResolveUDPAddr("udp", ac.RemoteAddr)
	if err != nil {
		logger.Fatal("resolve remote addr error", log.Error(err))
	}

	s := rtp.NewMultiStreamServer(localAddr,
		rtp.WithNewChannelHandler(func(s *rtp.MultiStreamServer, packet *rtp.Packet) bool {
			s.Stream(packet.Upk.UDPAddr, int64(packet.SSRC()), rtp.StreamHandlerFunc{HandleRTPPacketFn: func(s *rtp.MultiStreamServer, stream *rtp.SubStream, packet *rtp.Packet) {
				//s.SendTo(packet.Layer, remoteAddr)
				_ = remoteAddr
				packet.Release()
			}})
			return true
		}),
		rtp.WithQueueSize(ac.QueueSize),
		rtp.WithErrorHandler(func(s *rtp.MultiStreamServer, err error) {
			s.Logger().ErrorWith("parse rtp packet error", err)
		}),
		rtp.WithUDPOptions(udp.WithStatistic(true), udp.WithName("rtp server"),
			udp.WithReadBuffer(ac.ReadBuffer), udp.WithWriteBuffer(ac.WriteBuffer)),
	)
	monitor := s.NewMonitor()
	go func() {
		for {
			time.Sleep(time.Second)
			logger.Info(monitor.GetRuntimeInfo().String())
		}
	}()
	os.Exit(svc.New("rtp-proxy", s).Run())
}
