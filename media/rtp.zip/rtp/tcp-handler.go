package rtp

type TCPHandler interface {
	HandleRTPPacket(stream TCPStream, packet *TCPPacket)

	OnRTPChannelClose(stream TCPStream)
}

type TCPHandlerFunc struct {
	HandleRTPPacketFn   func(stream TCPStream, packet *TCPPacket)
	OnRTPChannelCloseFn func(stream TCPStream)
}

func (h TCPHandlerFunc) HandleRTPPacket(stream TCPStream, packet *TCPPacket) {
	if handleRTPPacketFn := h.HandleRTPPacketFn; handleRTPPacketFn != nil {
		handleRTPPacketFn(stream, packet)
	} else {
		packet.Release()
	}
}

func (h TCPHandlerFunc) OnRTPChannelClose(stream TCPStream) {
	if onRTPChannelCloseFn := h.OnRTPChannelCloseFn; onRTPChannelCloseFn != nil {
		onRTPChannelCloseFn(stream)
	}
}
