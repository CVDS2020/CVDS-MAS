package rtp

import (
	"fmt"
	"gitee.com/sy_183/common/component"
	"gitee.com/sy_183/common/lifecycle"
	"gitee.com/sy_183/common/log"
	"gitee.com/sy_183/common/pool"
	"gitee.com/sy_183/cvds-mas/config"
	"gitee.com/sy_183/cvds-mas/transport/udp"
	"net"
)

type Manager interface {
	lifecycle.Lifecycle

	Name() string

	Addr() *net.IPAddr

	Alloc() Server

	Free(s Server)
}

var manager = component.Pointer[Manager]{
	Init: func() *Manager {
		var manager Manager
		cfg := config.MediaRTPConfig()
		var udpOptions []udp.Option
		if cfg.UDP.Buffer != 0 {
			udpOptions = append(udpOptions, udp.WithBufferPool(pool.NewDataPool(cfg.UDP.Buffer.Uint())))
		}
		if cfg.UDP.ReadBuffer != 0 {
			udpOptions = append(udpOptions, udp.WithReadBuffer(cfg.UDP.ReadBuffer))
		}
		if cfg.UDP.WriteBuffer != 0 {
			udpOptions = append(udpOptions, udp.WithWriteBuffer(cfg.UDP.ReadBuffer))
		}
		var serverOptions []ServerOption
		if cfg.QueueSize != 0 {
			serverOptions = append(serverOptions, WithQueueSize(cfg.QueueSize))
		}
		if len(udpOptions) > 0 {
			serverOptions = append(serverOptions, WithUDPOptions(udpOptions...))
		}
		options := []ManagerOption{
			WithAddr(cfg.ListenIPAddr()),
			WithPortRange(cfg.PortRange.Start, cfg.PortRange.End, cfg.PortRange.Excludes...),
		}
		if len(serverOptions) > 0 {
			options = append(options, WithServerOptions(serverOptions...))
		}
		for _, port := range cfg.Ports {
			options = append(options, WithPort(port.RTP, port.RTCP))
		}
		if cfg.MultiStream && cfg.ServerMaxStreams > 0 {
			options = append(options, WithServerMaxStreams(cfg.ServerMaxStreams))
		}

		if cfg.MultiStream {
			manager = NewMultiStreamManager("rtp multi stream manager", options...)
		} else {
			manager = NewSingleStreamManager("rtp single stream manager", options...)
		}
		if err := manager.Start(); err != nil {
			Logger().Fatal(fmt.Sprintf("%s start failed", manager.Name()), log.Error(err))
		}
		return &manager
	},
}

func GetManager() Manager {
	return *manager.Get()
}
