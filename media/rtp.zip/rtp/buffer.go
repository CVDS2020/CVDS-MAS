package rtp

import (
	"gitee.com/sy_183/common/log"
	"gitee.com/sy_183/common/pool"
	"sync/atomic"
)

type Buffer struct {
	buffer []byte
	ref    atomic.Int64
	pool   BufferPool
}

func (b *Buffer) Get() []byte {
	return b.buffer
}

func (b *Buffer) Alloc(size uint) *Data {
	if size > uint(len(b.buffer)) {
		return &Data{Data: make([]byte, size)}
	}
	d := &Data{
		Data:   b.buffer[:size],
		buffer: b,
	}
	b.AddRef()
	b.buffer = b.buffer[size:]
	return d
}

func (b *Buffer) Release() {
	if c := b.ref.Add(-1); c == 0 {
		b.pool.pool.Put(b)
	} else if c < 0 {
		Logger().Fatal("repeat release buffer reference", log.Int64("old ref", c+1), log.Int64("ref", c))
	}
}

func (b *Buffer) AddRef() {
	if c := b.ref.Add(1); c <= 0 {
		Logger().Fatal("invalid buffer reference", log.Int64("old ref", c-1), log.Int64("ref", c))
	}
}

func (b *Buffer) Use() *Buffer {
	b.AddRef()
	return b
}

type Data struct {
	Data   []byte
	buffer *Buffer
}

func (d *Data) Release() {
	if d.buffer != nil {
		d.buffer.Release()
	}
}

func (d *Data) AddRef() {
	if d.buffer != nil {
		d.buffer.AddRef()
	}
}

func (d *Data) Use() *Data {
	d.AddRef()
	return d
}

type BufferPool struct {
	pool *pool.Pool[*Buffer]
}

func NewBufferPool(size uint) BufferPool {
	p := BufferPool{}
	p.pool = pool.NewPool(func(_ *pool.Pool[*Buffer]) *Buffer {
		b := &Buffer{
			buffer: make([]byte, size),
			ref:    atomic.Int64{},
			pool:   p,
		}
		b.ref.Add(1)
		return b
	})
	return p
}

func (p BufferPool) Get() *Buffer {
	return p.pool.Get().Use()
}
