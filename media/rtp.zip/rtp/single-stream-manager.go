package rtp

import (
	"gitee.com/sy_183/common/flag"
	"gitee.com/sy_183/common/lifecycle"
	"net"
	"reflect"
	"sync"
	"time"
)

const (
	retryableStateInterrupt = 1 << iota
	retryableStateStopped
	retryableStateStarting
)
const (
	serverStateStarting = 1 << iota
	serverStateStop
	serverStateStopping
	serverStateStopped
)

type serverContext struct {
	server *RetryableServer
	state  int
	//used   int
	port Port
	mu   sync.Mutex
}

func (e *serverContext) lock() {
	e.mu.Lock()
}

func (e *serverContext) unlock() {
	e.mu.Unlock()
}

type SingleStreamManager struct {
	lifecycle.Lifecycle
	name string
	addr *net.IPAddr

	// server options use to create server
	serverOptions []ServerOption

	// server contexts use to store all server
	contexts []*serverContext

	// server -> serverContext map, find the serverContext corresponding
	// to the server when it is released
	serverContext map[Server]*serverContext
	// alloc server contexts index
	curIndex int

	// alloc server max retry
	maxRetry int
	// server exit or start failed restart interval
	serverRestartInterval time.Duration

	mu sync.Mutex
}

func NewSingleStreamManager(name string, options ...ManagerOption) *SingleStreamManager {
	m := &SingleStreamManager{
		name:                  name,
		addr:                  &net.IPAddr{IP: net.IP{0, 0, 0, 0}},
		serverContext:         make(map[Server]*serverContext),
		serverRestartInterval: time.Second,
	}

	// apply options
	os := make(map[reflect.Type][]any)
	for _, option := range options {
		if opt := option.apply(m); opt != nil {
			os[reflect.TypeOf(opt)] = append(os[reflect.TypeOf(opt)], opt)
		}
	}

	// parse option result
	var ports Ports
	if ops := os[reflect.TypeOf(Ports{})]; len(ops) > 0 {
		for _, opt := range ops {
			ports = append(ports, opt.(Ports)...)
		}
	} else if ops := os[reflect.TypeOf(Port{})]; len(ops) > 0 {
		for _, opt := range ops {
			ports = append(ports, opt.(Port))
		}
	}
	if len(ports) == 0 {
		ports = append(ports, Port{
			RTP:  5004,
			RTCP: 5104,
		})
	}
	var sos []ServerOption
	if ops := os[reflect.TypeOf(sos)]; len(ops) > 0 {
		for _, opt := range ops {
			sos = append(sos, opt.([]ServerOption)...)
		}
	}
	m.serverOptions = sos

	if ops := os[reflect.TypeOf(RetryIntervalOption(0))]; len(ops) > 0 {
		m.serverRestartInterval = time.Duration(ops[len(ops)-1].(RetryIntervalOption))
	}

	m.contexts = make([]*serverContext, len(ports))
	if m.maxRetry == 0 {
		m.maxRetry = len(m.contexts)
	}

	for i, port := range ports {
		m.contexts[i] = &serverContext{
			state: serverStateStop | serverStateStopped,
			port:  port,
		}
	}

	_, m.Lifecycle = lifecycle.New(name, lifecycle.Context(m.run))
	return m
}

func (m *SingleStreamManager) run(interrupter chan struct{}) error {
	<-interrupter
	var runningFutures []chan error
	var startingEndpoints []*serverContext
	var closedFutures []chan error

	for _, ctx := range m.contexts {
		ctx.lock()
		// firstStop表示server没有标记stop
		firstStop := !flag.TestFlag(ctx.state, serverStateStop)
		if firstStop {
			// 没有标记stop则标记上
			ctx.state = flag.MaskFlag(ctx.state, serverStateStop)
		}
		if flag.TestFlag(ctx.state, serverStateStarting) {
			// server正在启动，此时已经标记了stop标志，启动后会自动关闭，
			// 这里只需要添加一个追踪启动完成的channel
			runningFutures = append(runningFutures, ctx.server.AddRunningFuture(nil))
		} else if !flag.TestFlag(ctx.state, serverStateStopped) {
			// server正在运行
			if firstStop {
				// 如果之前没有标记过stop，此时需要主动关闭
				ctx.server.Close(nil)
			}
			// 添加一个追踪关闭完成的channel
			closedFutures = append(closedFutures, ctx.server.AddClosedFuture(nil))
		}
		ctx.unlock()
	}

	// 等待那些处于staring的server启动完成
	for i, future := range runningFutures {
		if err := <-future; err == nil {
			// 启动成功了，需要继续追踪其关闭
			closedFutures = append(closedFutures, startingEndpoints[i].server.AddClosedFuture(nil))
		}
	}
	// 等待所有的server关闭
	for _, future := range closedFutures {
		<-future
	}
	return nil
}

func (m *SingleStreamManager) Name() string {
	return m.name
}

func (m *SingleStreamManager) setAddr(addr *net.IPAddr) {
	m.addr = addr
}

func (m *SingleStreamManager) Addr() *net.IPAddr {
	return m.addr
}

func (m *SingleStreamManager) alloc() *serverContext {
	var retryCount int
	var ctx *serverContext
retry:
	m.mu.Lock()
	for {
		ctx = m.contexts[m.curIndex]
		if m.curIndex++; m.curIndex == len(m.contexts) {
			m.curIndex = 0
		}
		ctx.lock() // first lock
		if flag.TestFlag(ctx.state, serverStateStopped) &&
			!flag.TestFlag(ctx.state, serverStateStarting) {
			// 已经被关闭并且不是处在正在打开状态的server一定可以被分配
			if ctx.server == nil {
				server := NewSingleStreamServer(&net.UDPAddr{
					IP:   m.addr.IP,
					Port: int(ctx.port.RTP),
					Zone: m.addr.Zone,
				}, m.serverOptions...)
				ctx.server = NewRetryableServer(server, m.serverRestartInterval)
				_, ctx.server.Lifecycle = lifecycle.New("", lifecycle.Context(ctx.server.run))
				m.serverContext[server] = ctx
			}
			// 可以配分配的(已经被关闭并且不是处在正在打开状态的)server一定被标记了stop标志，
			// 需要取消标记stop，并且将状态转换为starting
			ctx.state = flag.SwapFlagMask(ctx.state, serverStateStop, serverStateStarting)
			ctx.unlock() // first unlock
			break
		}
		ctx.unlock() // first unlock
		if retryCount++; retryCount > m.maxRetry {
			m.mu.Unlock()
			return nil
		}
	}
	m.mu.Unlock()

	// do start server
	err := ctx.server.Start()

	ctx.lock() // second lock
	// 不管是否成功启动server，都不是正在打开的状态，需要取消标记starting
	ctx.state = flag.UnmaskFlag(ctx.state, serverStateStarting)
	if err == nil {
		// server启动成功，一定不是stopped状态， 取消stopped标记
		ctx.state = flag.UnmaskFlag(ctx.state, serverStateStopped)
		if flag.TestFlag(ctx.state, serverStateStop) {
			// 如果在启动server的过程中被标记了stop(通过调用freeEndpoint或这关闭manager)，
			// 那么立刻关闭server并标记server为stopping状态
			flag.TestFlag(ctx.state, serverStateStopping)
			ctx.server.Close(nil)
			go func() {
				// 追踪server关闭情况，一旦关闭了，需要将server状态从stopping转变为
				// stopped
				<-ctx.server.AddClosedFuture(nil)
				ctx.lock()
				ctx.state = flag.SwapFlagMask(ctx.state, serverStateStopping, serverStateStopped)
				ctx.unlock()
			}()
			ctx.unlock() // second unlock
			return nil
		}
		ctx.unlock()
		return ctx
	}
	// server启动失败，如果在启动server的过程中被标记了stop(通过调用freeEndpoint或这关闭
	// manager)，此时直接退出
	if flag.TestFlag(ctx.state, serverStateStop) {
		ctx.unlock()
		return nil
	}
	// 将server标记为stop，重试申请server
	ctx.state = flag.UnmaskFlag(ctx.state, serverStateStop)
	ctx.unlock()
	if retryCount++; retryCount > m.maxRetry {
		return nil
	}
	goto retry
}

func (m *SingleStreamManager) Alloc() Server {
	endpoint := m.alloc()
	if endpoint == nil {
		return nil
	}
	return endpoint.server.server
}

func (m *SingleStreamManager) free(ctx *serverContext) {
	ctx.lock()
	// 如果已经标记了stop，则此endpoint已经被释放或者正在释放
	if flag.TestFlag(ctx.state, serverStateStop) {
		ctx.unlock()
		return
	}
	// 将endpoint标记stop
	ctx.state = flag.MaskFlag(ctx.state, serverStateStop)
	if !flag.TestFlag(ctx.state, serverStateStarting) {
		// 此处不可能是stopped，以为如果不是starting状态时处于stopped状态
		// 一定标记了stop，而标记了stop的在此函数开始时就被过滤掉了
		ctx.server.Close(nil)
		go func() {
			<-ctx.server.AddClosedFuture(nil)
			ctx.lock()
			ctx.state = flag.SwapFlagMask(ctx.state, serverStateStopping, serverStateStopped)
			ctx.unlock()
		}()
	}
	// endpoint的server正在启动，此时被标记了stop标志，启动后会自动关闭，
	// 这里什么都不需要做
	ctx.unlock()
}

func (m *SingleStreamManager) Free(s Server) {
	m.mu.Lock()
	ctx := m.serverContext[s]
	if ctx == nil {
		m.mu.Lock()
		return
	}
	m.mu.Unlock()
	m.free(ctx)
}
