package rtp

import "gitee.com/sy_183/common/errors"

var (
	InvalidVersionError = errors.New("rtp version must be 2")

	CSRCLengthOutOfRange = errors.New("rtp CSRC length out of range(0, 15)")

	ExtensionLengthOutOfRange = errors.New("rtp extension length out of range(0, 65535)")

	PayloadLengthOutOfRange = errors.New("rtp payload length out of range(0, 65535)")

	ZeroPaddingLengthError = errors.New("rtp padding length must not be zero")

	PacketSizeNotEnoughError = errors.New("rtp packet size not enough")
)
