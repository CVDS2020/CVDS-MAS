package rtp

import (
	"encoding/binary"
	"gitee.com/sy_183/common/id"
	"gitee.com/sy_183/common/uns"
	"gitee.com/sy_183/cvds-mas/transport/udp"
	"net"
	"sync"
	"sync/atomic"
	"time"
)

const DefaultUDPQueueSize = 512

type MultiStreamServer struct {
	abstractServer

	newChannelHandler   atomic.Pointer[func(s *MultiStreamServer, packet *Packet) bool]
	streamSocketSSRCMap map[string]*SubStream
	streamSSRCMap       map[uint32]*SubStream
	streamSocketMap     map[string]*SubStream

	mu sync.Mutex
}

func NewMultiStreamServer(addr *net.UDPAddr, options ...ServerOption) *MultiStreamServer {
	s := new(MultiStreamServer)
	s.init(addr, nil, options...)
	return s
}

func NewMultiStreamServerWithUDP(udpServer *udp.Server, options ...ServerOption) *MultiStreamServer {
	s := new(MultiStreamServer)
	s.init(nil, udpServer, options...)
	return s
}

func (s *MultiStreamServer) init(addr *net.UDPAddr, udpServer *udp.Server, options ...ServerOption) {
	s.SetNewChannelHandler(nil)
	s.streamSocketSSRCMap = make(map[string]*SubStream)
	s.streamSSRCMap = make(map[uint32]*SubStream)
	s.streamSocketMap = make(map[string]*SubStream)
	s.abstractServer.init(s, addr, udpServer, options...)
}

func (s *MultiStreamServer) GetNewChannelHandler() func(s *MultiStreamServer, packet *Packet) bool {
	return *s.newChannelHandler.Load()
}

func (s *MultiStreamServer) SetNewChannelHandler(handler func(s *MultiStreamServer, packet *Packet) bool) *MultiStreamServer {
	s.newChannelHandler.Store(&handler)
	return s
}

func (s *MultiStreamServer) handlePacket(upk *udp.Packet) error {
	if upk.Data == nil {
		s.mu.Lock()
		if stream, has := s.streamSocketSSRCMap[sockSSRCId]; has {
			s.mu.Unlock()
			stream.HandleRTPPacket(stream, packet)
		} else if stream, has := s.streamSocketMap[sockId]; has {
			s.mu.Unlock()
			stream.HandleRTPPacket(stream, packet)
		} else if stream, has := s.streamSSRCMap[ssrc]; has {
			s.mu.Unlock()
			stream.HandleRTPPacket(stream, packet)
		}
	}
	layer := s.pool.Get()
	err := layer.Unmarshal(upk.Data.Data)
	if err != nil {
		upk.Release()
		s.pool.Put(layer)
		return err
	}

	sockId := id.GenerateUdpAddrId(upk.UDPAddr)
	ssrc := layer.SSRC()
	ssrcIdBuf := [4]byte{}
	binary.BigEndian.PutUint32(ssrcIdBuf[:], ssrc)
	sockSSRCId := sockId + uns.BytesToString(ssrcIdBuf[:])
	packet := NewPacket(layer, PacketUDP(upk), PacketTime(time.Now()), PacketLayerPool(s.pool))

	isRetry := false
retry:
	s.mu.Lock()
	if stream, has := s.streamSocketSSRCMap[sockSSRCId]; has {
		s.mu.Unlock()
		stream.HandleRTPPacket(stream, packet)
	} else if stream, has := s.streamSocketMap[sockId]; has {
		s.mu.Unlock()
		stream.HandleRTPPacket(stream, packet)
	} else if stream, has := s.streamSSRCMap[ssrc]; has {
		s.mu.Unlock()
		stream.HandleRTPPacket(stream, packet)
	} else if newChannelHandler := s.GetNewChannelHandler(); newChannelHandler != nil && !isRetry {
		s.mu.Unlock()
		if newChannelHandler(s, packet) {
			isRetry = true
			goto retry
		}
		packet.Release()
		return nil
	} else {
		s.mu.Unlock()
		packet.Release()
	}
	return nil
}

func (s *MultiStreamServer) Stream(addr *net.UDPAddr, ssrc int64, handler Handler) *SubStream {
	var sockId, ssrcId, sockSSRCId string
	if addr != nil {
		sockId = id.GenerateUdpAddrId(addr)
	}
	if ssrc >= 0 {
		ssrcIdBuf := make([]byte, 4)
		binary.BigEndian.PutUint32(ssrcIdBuf, uint32(ssrc))
		ssrcId = uns.BytesToString(ssrcIdBuf)
	}
	if sockId != "" && ssrc >= 0 {
		sockSSRCId = sockId + ssrcId
	}
	stream := &SubStream{
		server:     s,
		sockID:     sockId,
		ssrc:       ssrc,
		sockSSRCID: sockSSRCId,
	}
	stream.SetHandler(handler)
	stream.SetRemoteAddr(addr)
	s.mu.Lock()
	defer s.mu.Unlock()
	if sockSSRCId != "" {
		s.streamSocketSSRCMap[sockSSRCId] = stream
	} else if sockId != "" {
		s.streamSocketMap[sockId] = stream
	} else if ssrc >= 0 {
		s.streamSSRCMap[uint32(ssrc)] = stream
	} else {
		return nil
	}
	return stream
}

func (s *MultiStreamServer) RemoveStream(stream *SubStream) {
	if stream.server != s {
		return
	}
	s.mu.Lock()
	if stream.sockSSRCID != "" {
		delete(s.streamSocketSSRCMap, stream.sockSSRCID)
	} else if stream.sockID != "" {
		delete(s.streamSocketMap, stream.sockID)
	} else if stream.ssrc >= 0 {
		delete(s.streamSSRCMap, uint32(stream.ssrc))
	}
	s.mu.Unlock()
	s.queueStreamClosePacket(&udp.Packet{
		UDPAddr: stream.remoteAddr.Load(),
	})
}
