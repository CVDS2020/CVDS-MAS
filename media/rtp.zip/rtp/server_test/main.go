package main

import (
	"gitee.com/sy_183/common/assert"
	"gitee.com/sy_183/common/log"
	svc "gitee.com/sy_183/common/system/service"
	"gitee.com/sy_183/common/unit"
	"gitee.com/sy_183/cvds-mas/media/rtp"
	"gitee.com/sy_183/cvds-mas/transport/udp"
	"net"
	"os"
	"time"
)

var logger = assert.Must(log.Config{
	Encoder: log.NewConsoleEncoder(log.ConsoleEncoderConfig{
		DisableTime:     true,
		DisableCaller:   true,
		DisableFunction: true,
		EncodeLevel:     log.CapitalColorLevelEncoder,
	}),
}.Build())

func main() {
	//dis := assert.Must(net.ResolveUDPAddr("udp", "127.0.0.1:5903"))
	s := rtp.NewMultiStreamServer(assert.Must(net.ResolveUDPAddr("udp", "0.0.0.0:5004")),
		rtp.WithNewChannelHandler(func(s *rtp.MultiStreamServer, packet *rtp.Packet) bool {
			s.Stream(packet.Upk.UDPAddr, int64(packet.SSRC()), rtp.HandlerFunc{HandleRTPPacketFn: func(stream rtp.Stream, packet *rtp.Packet) {
				//ps := packet.String()
				//go s.Logger().Info(ps)
				//s.SendTo(packet.Layer, dis)
				packet.Release()
			}})
			return true
		}),
		rtp.WithQueueSize(1),
		rtp.WithErrorHandler(func(s rtp.Server, err error) {
			logger.ErrorWith("parse rtp packet error", err)
		}),
		rtp.WithUDPOptions(udp.WithStatistic(true), udp.WithName("rtp server"),
			udp.WithReadBuffer(1*unit.MeBiByte), udp.WithWriteBuffer(1*unit.MeBiByte)),
	)
	monitor := s.UDPServer().NewMonitor()
	go func() {
		for {
			time.Sleep(time.Second)
			logger.Info(monitor.GetRuntimeInfo().String())
		}
	}()
	os.Exit(svc.New("server-test", s).Run())
}
