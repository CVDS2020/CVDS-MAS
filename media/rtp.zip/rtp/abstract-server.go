package rtp

import (
	"fmt"
	"gitee.com/sy_183/common/def"
	"gitee.com/sy_183/common/lifecycle"
	"gitee.com/sy_183/common/pool"
	"gitee.com/sy_183/common/utils"
	"gitee.com/sy_183/cvds-mas/transport/udp"
	"net"
	"reflect"
	"sync/atomic"
)

type abstractServer struct {
	lifecycle.Lifecycle
	this serverPrivate
	us   *udp.Server

	pool              *pool.SyncPool[*Layer]
	writePool         *pool.DataPool
	queue             chan *udp.Packet
	streamCloseSignal chan Stream

	errorHandler atomic.Pointer[func(s Server, err error)]
	onStarted    atomic.Pointer[func(s Server)]
	onClosed     atomic.Pointer[func(s Server, err error)]
}

func (s *abstractServer) init(self serverPrivate, addr *net.UDPAddr, udpServer *udp.Server, options ...ServerOption) {
	s.this = self
	s.SetErrorHandler(nil)
	s.OnStarted(nil)
	s.OnClosed(nil)
	// option result type value map
	os := make(map[reflect.Type][]any)
	for _, option := range options {
		if opt := option.apply(s.this); opt != nil {
			os[reflect.TypeOf(opt)] = append(os[reflect.TypeOf(opt)], opt)
		}
	}
	def.SetterDefaultP(&s.pool, func() *pool.Pool[*Layer] {
		return pool.NewPool[*Layer](func(p *pool.Pool[*Layer]) *Layer {
			return NewLayer()
		})
	})
	def.SetterDefaultP(&s.writePool, func() *pool.DataPool { return pool.NewDataPool(udp.DefaultPoolSize) })
	def.MakeChanP(&s.queue, DefaultUDPQueueSize)

	if udpServer != nil {
		s.us = udpServer.SetPacketHandler(s.this.queuePacket)
		return
	}
	var uos []udp.Option
	if ops := os[reflect.TypeOf(uos)]; len(ops) > 0 {
		for _, opt := range ops {
			uos = append(uos, opt.([]udp.Option)...)
		}
	}
	var name string
	if ops := os[reflect.TypeOf(NameOption(""))]; len(ops) > 0 {
		name = string(ops[len(ops)-1].(NameOption))
	} else {
		name = fmt.Sprintf("rtp server(%s)", addr.String())
	}
	uos = append(uos, udp.WithName(name))
	s.us = udp.NewServer(addr, s.queuePacket, uos...)

	_, s.Lifecycle = lifecycle.New(name, lifecycle.Core(s.this.start, s.this.run, s.this.close), lifecycle.Self(self))
}

func (s *abstractServer) start() error {
	return s.us.Start()
}

func (s *abstractServer) run() error {
	if callback := s.this.OnStartedCallback(); callback != nil {
		callback(s)
	}
	future := s.us.AddClosedFuture(nil)
	var err error
	for true {
		select {
		case upk := <-s.queue:
			if err := s.this.handlePacket(upk); err != nil {
				s.this.handleError(err)
			}
		case stream := <-s.streamCloseSignal:

		case err = <-future:
			goto doClose
		}
	}

doClose:
	for remain := len(s.queue); remain > 0; remain-- {
		select {
		case upk := <-s.queue:
			if err := s.this.handlePacket(upk); err != nil {
				s.this.handleError(err)
			}
		default:
			break
		}
	}
	if callback := s.this.OnClosedCallback(); callback != nil {
		callback(s, err)
	}
	return err
}

func (s *abstractServer) close() error {
	return s.us.Close(nil)
}

func (s *abstractServer) queuePacket(us *udp.Server, upk *udp.Packet) bool {
	select {
	case s.queue <- upk:
		// channel not full, push udp packet to channel
		return true
	default:
		// channel full, drop this udp packet
		upk.Release()
		return false
	}
}

func (s *abstractServer) queueStreamClosePacket(upk *udp.Packet) {
	utils.ChanAsyncPush(s.queue, upk)
}

func (s *abstractServer) handlePacket(upk *udp.Packet) error {
	panic("not implement")
}

func (s *abstractServer) handleError(err error) {
	if errorHandler := s.this.ErrorHandler(); errorHandler != nil {
		errorHandler(s, err)
	}
}

func (s *abstractServer) Name() string {
	return s.us.Name()
}

func (s *abstractServer) UDPServer() *udp.Server {
	return s.us
}

func (s *abstractServer) UDPAddr() *net.UDPAddr {
	return s.us.Addr()
}

func (s *abstractServer) ErrorHandler() func(s Server, err error) {
	return *s.errorHandler.Load()
}

func (s *abstractServer) SetErrorHandler(handler func(s Server, err error)) Server {
	s.errorHandler.Store(&handler)
	return s.this
}

func (s *abstractServer) OnStartedCallback() func(s Server) {
	return *s.onStarted.Load()
}

func (s *abstractServer) OnStarted(callback func(s Server)) Server {
	s.onStarted.Store(&callback)
	return s.this
}

func (s *abstractServer) OnClosedCallback() func(s Server, err error) {
	return *s.onClosed.Load()
}

func (s *abstractServer) OnClosed(callback func(s Server, err error)) Server {
	s.onClosed.Store(&callback)
	return s.this
}

func (s *abstractServer) SendTo(layer *Layer, addr *net.UDPAddr) error {
	size := layer.Size()
	data := s.writePool.Alloc(size)
	layer.Read(data.Data)
	_, err := s.us.SendTo(data.Data, addr)
	data.Release()
	return err
}
