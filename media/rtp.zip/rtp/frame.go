package rtp

import (
	"gitee.com/sy_183/common/pool"
	"io"
	"sync/atomic"
	"time"
)

type FrameLayer struct {
	Timestamp uint32
	Layers    []*Layer
}

func (f *Frame) Len() uint {
	return uint(len(f.Layers))
}

func (f *Frame) Size() uint {
	var s uint
	for _, layer := range f.Layers {
		s += layer.PayloadLength()
	}
	return s
}

func (l *FrameLayer) Append(layer *Layer) {
	l.Layers = append(l.Layers, layer)
}

func (l *FrameLayer) WriteTo(w io.Writer) (n int64, err error) {
	for _, layer := range l.Layers {
		if err = write(w, layer.payloadContent, &n); err != nil {
			return
		}
	}
	return
}

func (l *FrameLayer) Read(p []byte) (n int, err error) {
	w := writer{buf: p}
	n64, _ := l.WriteTo(&w)
	return int(n64), io.EOF
}

type Frame struct {
	FrameLayer
	Packets   []*Packet
	StartTime time.Time
	EndTime   time.Time
	ref       int64
	pool      *pool.SyncPool[*Frame]
}

func timeRangeExpand(start, end *time.Time, cur time.Time, timeNodeLen int) {
	if start.After(*end) {
		panic("start time after end time")
	}
	if start.IsZero() {
		*start = cur
		*end = cur
	} else {
		du := cur.Sub(*end)
		if du < 0 {
			guess := time.Duration(0)
			if timeNodeLen > 2 {
				guess = (end.Sub(*start)) / time.Duration(timeNodeLen-2)
			}
			offset := du - guess
			*start = start.Add(offset)
		}
		*end = cur
	}
}

func (f *Frame) Append(packet *Packet) {
	if len(f.Packets) == 0 {
		f.Timestamp = packet.timestamp
	} else if packet.timestamp != f.Timestamp {
		return
	}
	f.FrameLayer.Append(packet.Layer)
	f.Packets = append(f.Packets, packet.Use())
	timeRangeExpand(&f.StartTime, &f.EndTime, packet.Time, len(f.Packets))
}

var zeroTime = time.Time{}

func (f *Frame) Release() {
	if c := atomic.AddInt64(&f.ref, -1); c == 0 {
		f.Layers = f.Layers[:0]
		for _, packet := range f.Packets {
			packet.Release()
		}
		f.Packets = f.Packets[:0]
		f.Timestamp = 0
		f.StartTime, f.EndTime = zeroTime, zeroTime
		if f.pool != nil {
			f.pool.Put(f)
		}
	} else if c < 0 {
		Logger().Fatal("rtp frame repeat release")
	}
}

func (f *Frame) AddRef() {
	if atomic.AddInt64(&f.ref, 1) <= 0 {
		Logger().Fatal("invalid rtp frame reference count")
	}
}

func (f *Frame) Use() *Frame {
	f.AddRef()
	return f
}
