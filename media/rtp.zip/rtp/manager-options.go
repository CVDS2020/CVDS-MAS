package rtp

import (
	"gitee.com/sy_183/common/log"
	"net"
	"time"
)

// An ManagerOption configures a MultiStreamManager.
type ManagerOption interface {
	apply(m Manager) any
}

// managerOptionFunc wraps a func, so it satisfies the ManagerOption interface.
type managerOptionFunc func(m Manager) any

func (f managerOptionFunc) apply(m Manager) any {
	return f(m)
}

func WithServerOptions(options ...ServerOption) ManagerOption {
	return managerOptionFunc(func(m Manager) any {
		return options
	})
}

type Port struct {
	RTP  uint16
	RTCP uint16
}

type Ports []Port

func WithServerMaxStreams(streams uint) ManagerOption {
	return managerOptionFunc(func(m Manager) any {
		if mm, is := m.(*MultiStreamManager); is {
			mm.serverMaxStreams = streams
		}
		return nil
	})
}

type RetryIntervalOption time.Duration

func WithRetryInterval(interval time.Duration) ManagerOption {
	return managerOptionFunc(func(m Manager) any {
		return RetryIntervalOption(interval)
	})
}

func WithAddr(addr *net.IPAddr) ManagerOption {
	type addrSetter interface {
		setAddr(addr *net.IPAddr)
	}
	return managerOptionFunc(func(m Manager) any {
		if setter, is := m.(addrSetter); is {
			setter.setAddr(addr)
		}
		return nil
	})
}

func WithPortRange(start uint16, end uint16, excludes ...uint16) ManagerOption {
	excludeSet := make(map[uint16]struct{})
	for _, exclude := range excludes {
		excludeSet[exclude] = struct{}{}
	}
	return managerOptionFunc(func(m Manager) any {
		var ports Ports
		for i := start; i < end; i += 2 {
			if _, in := excludeSet[i]; in {
				continue
			}
			if _, in := excludeSet[i+1]; in {
				continue
			}
			ports = append(ports, Port{RTP: i, RTCP: i + 1})
		}
		return ports
	})
}

func WithPort(rtp uint16, rtcp uint16) ManagerOption {
	return managerOptionFunc(func(m Manager) any {
		return Port{RTP: rtp, RTCP: rtcp}
	})
}

func WithManagerLogger(logger *log.Logger) ManagerOption {
	type loggerSetter interface {
		setLogger(logger *log.Logger)
	}
	return managerOptionFunc(func(m Manager) any {
		if setter, is := m.(loggerSetter); is {
			setter.setLogger(logger)
		}
		return nil
	})
}
