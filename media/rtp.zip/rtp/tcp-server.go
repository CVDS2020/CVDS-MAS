package rtp

import (
	"gitee.com/sy_183/common/lifecycle"
	"gitee.com/sy_183/common/pool"
	"net"
	"sync/atomic"
	"time"
)

type TCPServer interface {
	lifecycle.Lifecycle

	Name() string

	TCPAddr() *net.TCPAddr

	OnStartedCallback() func(s Server)

	OnStarted(callback func(s Server)) Server

	OnClosedCallback() func(s Server, err error)

	OnClosed(callback func(s Server, err error)) Server
}

type TCPChannel struct {
	lifecycle.OnceLifecycle

	server *DefaultTCPServer

	conn *net.TCPConn

	handler atomic.Pointer[TCPHandler]

	queue chan *pool.Data

	layerPool *pool.Pool[*Layer]

	parser *Parser

	chunks []*Data
}

func (c *TCPChannel) clearChunks() {
	for _, chunk := range c.chunks {
		chunk.Release()
	}
	c.chunks = c.chunks[:0]
}

//func (c *TCPChannel) handleBuffer(buf *pool.Data) error {
//	c
//	return nil
//}
//
//func (c *TCPChannel) handlerRun(interrupter chan struct{}) error {
//	for true {
//		select {
//		case upk := <-c.queue:
//			if err := c.handleBuffer(upk); err != nil {
//				c.handleError(err)
//			}
//		case <-interrupter:
//			goto doClose
//		}
//	}
//
//doClose:
//	for remain := len(c.queue); remain > 0; remain-- {
//		select {
//		case upk := <-c.queue:
//			if err := c.handleBuffer(upk); err != nil {
//				c.handleError(err)
//			}
//		default:
//			break
//		}
//	}
//
//	return nil
//}

func (c *TCPChannel) run() error {
	bufferPool := c.server.bufferPool
	buffer := bufferPool.Get()
	defer func() {
		buffer.Release()
		c.clearChunks()
	}()
	for {
		buf := buffer.Get()
		if len(buf) < 2048 {
			buffer.Release()
			buffer = bufferPool.Get()
			buf = buffer.Get()
		}
		n, err := c.conn.Read(buf)
		if err != nil {
			return err
		}
		data := buffer.Alloc(uint(n))

		for {
			_, layer, remain, err := c.parser.Parse(data.Data)
			if layer != nil {
				if err != nil {
					c.clearChunks()
					c.parser.Set(layer)
				} else {
					c.chunks = append(c.chunks, data.Use())
					c.parser.Set(c.layerPool.Get())
					packet := NewPacket(layer, PacketChunks(c.chunks), PacketTime(time.Now()), PacketLayerPool(c.layerPool))
					c.chunks = c.chunks[:0]
				}
				if len(remain) == 0 {
					break
				}
				data.Data = remain
			} else {
				break
			}
		}

		data.Release()
	}
}

func (c *TCPChannel) Handler() TCPHandler {
	return *c.handler.Load()
}

func (c *TCPChannel) SetHandler(handler TCPHandler) *TCPChannel {
	c.handler.Store(&handler)
	return c
}

type DefaultTCPServer struct {
	// lifecycle API support
	lifecycle.Lifecycle

	// server core runner
	runner *lifecycle.DefaultRunner

	// the address of a TCP end point
	addr *net.TCPAddr

	// TCP listener connection
	listener *net.TCPListener

	// readBuffer is the size of the operating system's receive buffer
	// associated with the connection.
	readBuffer int

	// writeBuffer is the size of the operating system's transmit buffer
	// associated with the connection.
	writeBuffer int

	// bufferPool is used for alloc buffer to receive TCP data
	bufferPool BufferPool

	queueSize uint

	cons map[*TCPChannel]struct{}
}

func (s *DefaultTCPServer) newTCPChannel(conn *net.TCPConn) *TCPChannel {
	c := &TCPChannel{
		server: s,
		conn:   conn,
		queue:  make(chan *pool.Data, s.queueSize),
	}
	c.SetHandler(TCPHandlerFunc{})
	_, c.OnceLifecycle = lifecycle.New("", lifecycle.RunFn(c.run))
}

func (s *DefaultTCPServer) start() error {
	listener, err := net.ListenTCP("tcp", s.addr)
	if err != nil {
		return err
	}
	s.listener = listener
	return nil
}

func (s *DefaultTCPServer) run() error {
	for {
		conn, err := s.listener.AcceptTCP()
		if err != nil {
			s.runner.Lock()
			if s.runner.Closing() {
				s.runner.Unlock()
				return nil
			}
			s.runner.Unlock()
			return err
		}

	}

}

func (s *DefaultTCPServer) Addr() net.Addr {
	return s.addr
}
