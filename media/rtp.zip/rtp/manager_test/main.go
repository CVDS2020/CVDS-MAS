package main

import (
	"gitee.com/sy_183/common/assert"
	"gitee.com/sy_183/common/log"
	svc "gitee.com/sy_183/common/system/service"
	"gitee.com/sy_183/cvds-mas/media/rtp"
	"os"
)

var logger = assert.Must(log.Config{
	Encoder: log.NewConsoleEncoder(log.ConsoleEncoderConfig{
		DisableTime:       true,
		DisableCaller:     true,
		DisableFunction:   true,
		DisableStacktrace: true,
		EncodeLevel:       log.CapitalColorLevelEncoder,
	}),
}.Build())

func main() {
	manager := rtp.NewMultiStreamManager("test manager",
		rtp.WithManagerLogger(logger),
		rtp.WithPortRange(5004, 5054),
		rtp.WithServerOptions(rtp.OnStarted(func(s rtp.Server) {
			logger.Info("rtp server started", log.String("addr", s.UDPAddr().String()))
		}), rtp.OnClosed(func(s rtp.Server, err error) {
			if err != nil {
				logger.ErrorWith("rtp server stopped", err, log.String("addr", s.UDPAddr().String()))
			} else {
				logger.Info("rtp server stopped", log.String("addr", s.UDPAddr().String()))
			}
		})),
	)
	os.Exit(svc.New("test-manager", manager).Run())
}
