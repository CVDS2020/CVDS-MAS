package rtp

import "io"

type writer struct {
	buf []byte
	off int
}

func (w *writer) Write(p []byte) (n int, err error) {
	n = copy(w.buf[w.off:], p)
	w.off += n
	return
}

func write(w io.Writer, p []byte, np *int64) error {
	n, err := w.Write(p)
	*np += int64(n)
	return err
}

func writeTo(wt io.WriterTo, w io.Writer, np *int64) error {
	n, err := wt.WriteTo(w)
	*np += n
	return err
}
