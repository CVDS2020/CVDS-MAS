package rtp

const DefaultOrderedHandlerCached = 16

type OrderedHandler struct {
	handler Handler
	cache   []*Packet
	head    int
	init    bool
	seq     uint16
	dropped uint64
	repeat  uint64
}

func NewOrderedHandler(handler Handler, cached uint16) *OrderedHandler {
	if cached == 0 {
		cached = DefaultOrderedHandlerCached
	}
	return &OrderedHandler{
		handler: handler,
		cache:   make([]*Packet, cached),
	}
}

func (h *OrderedHandler) HandleRTPPacket(stream Stream, packet *Packet) {
	if !h.init {
		h.seq = packet.sequenceNumber
		h.handler.HandleRTPPacket(stream, packet)
		h.seq++
		h.init = true
		return
	}
	diff := packet.sequenceNumber - h.seq
	if int(diff) >= len(h.cache) {
		h.dropped++
		return
	}
	index := int(diff) + h.head
	if index > len(h.cache) {
		index -= len(h.cache)
	}
	if h.cache[index] != nil {
		h.repeat++
	}
	h.cache[index] = packet

	for h.cache[h.head] != nil {
		h.handler.HandleRTPPacket(stream, h.cache[h.head])
		h.cache[h.head] = nil
		h.seq++
		if h.head++; h.head == len(h.cache) {
			h.head = 0
		}
	}
}

func (h *OrderedHandler) OnRTPChannelClose(stream Stream) {
	for _, packet := range h.cache[h.head:] {
		if packet != nil {
			h.handler.HandleRTPPacket(stream, packet)
		}
	}
	for _, packet := range h.cache[:h.head] {
		if packet != nil {
			h.handler.HandleRTPPacket(stream, packet)
		}
	}
	h.handler.OnRTPChannelClose(stream)
}
