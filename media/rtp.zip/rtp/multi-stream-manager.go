package rtp

import (
	"gitee.com/sy_183/common/container"
	"gitee.com/sy_183/common/lifecycle"
	"gitee.com/sy_183/common/log"
	"gitee.com/sy_183/common/pool"
	"net"
	"reflect"
	"sync"
	"time"
)

type endpoint struct {
	*MultiStreamServer
	rtpPort  uint16
	rtcpPort uint16
	streams  uint
}

type MultiStreamManager struct {
	lifecycle.Lifecycle
	name  string
	group *lifecycle.Group

	addr             *net.IPAddr
	serverMaxStreams uint

	endpointsPool  *pool.SyncPool[map[*endpoint]struct{}]
	endpoints      *container.TreeMap[uint, map[*endpoint]struct{}]
	serverEndpoint map[Server]*endpoint

	mu     sync.Mutex
	logger *log.Logger
}

func NewMultiStreamManager(name string, options ...ManagerOption) *MultiStreamManager {
	// create manager
	m := &MultiStreamManager{
		name:             name,
		addr:             &net.IPAddr{IP: net.IP{0, 0, 0, 0}},
		serverMaxStreams: 8,
		endpointsPool: pool.NewPool[map[*endpoint]struct{}](func() map[*endpoint]struct{} {
			return make(map[*endpoint]struct{})
		}),
		endpoints:      &container.NewOrderedKeyTreeMap[uint, map[*endpoint]struct{}]().TreeMap,
		serverEndpoint: make(map[Server]*endpoint),
		logger:         Logger(),
	}

	// apply options
	os := make(map[reflect.Type][]any)
	for _, option := range options {
		if opt := option.apply(m); opt != nil {
			os[reflect.TypeOf(opt)] = append(os[reflect.TypeOf(opt)], opt)
		}
	}

	// parse option result
	var ports Ports
	if ops := os[reflect.TypeOf(Ports{})]; len(ops) > 0 {
		for _, opt := range ops {
			ports = append(ports, opt.(Ports)...)
		}
	} else if ops := os[reflect.TypeOf(Port{})]; len(ops) > 0 {
		for _, opt := range ops {
			ports = append(ports, opt.(Port))
		}
	}
	if len(ports) == 0 {
		ports = append(ports, Port{
			RTP:  5004,
			RTCP: 5005,
		})
	}
	var sos []ServerOption
	if ops := os[reflect.TypeOf(sos)]; len(ops) > 0 {
		for _, opt := range ops {
			sos = append(sos, opt.([]ServerOption)...)
		}
	}
	var retryInterval time.Duration
	if ops := os[reflect.TypeOf(RetryIntervalOption(0))]; len(ops) > 0 {
		retryInterval = time.Duration(ops[len(ops)-1].(RetryIntervalOption))
	} else {
		retryInterval = time.Second
	}

	// create contexts
	endpoints := make([]*endpoint, 0, len(ports))
	for _, port := range ports {
		endpoints = append(endpoints, &endpoint{
			MultiStreamServer: NewMultiStreamServer(&net.UDPAddr{
				IP:   m.addr.IP,
				Port: int(port.RTP),
				Zone: m.addr.Zone,
			}, sos...),
			rtcpPort: port.RTP,
			rtpPort:  port.RTCP,
		})
	}
	children := make([]lifecycle.ChildLifecycle, 0, len(ports))
	for _, endpoint := range endpoints {
		addr := endpoint.UDPAddr().String()
		children = append(children, lifecycle.ChildLifecycle{
			Lifecycle:     endpoint,
			RetryInterval: retryInterval,
			StartErrorCallback: func(err error) {
				m.logger.ErrorWith("rtp server start error", err, log.String("addr", addr))
			},
			CloseErrorCallback: func(err error) {
				m.logger.ErrorWith("rtp server close error", err, log.String("addr", addr))
			},
			ExitErrorCallback: func(err error) {
				m.logger.ErrorWith("rtp server exit error", err, log.String("addr", addr))
			},
		})
	}
	m.group = lifecycle.NewGroup(name, children, lifecycle.PreStart(true))
	m.Lifecycle = m.group
	return m
}

func (m *MultiStreamManager) Name() string {
	return m.name
}

func (m *MultiStreamManager) setAddr(addr *net.IPAddr) {
	m.addr = addr
}

func (m *MultiStreamManager) Addr() *net.IPAddr {
	return m.addr
}

func (m *MultiStreamManager) setLogger(logger *log.Logger) {
	m.logger = logger
}

func (m *MultiStreamManager) changeEndpointStreams(entry *container.TreeMapEntry[uint, map[*endpoint]struct{}], endpoint *endpoint, streams uint) {
	endpoints := entry.Value()
	if delete(endpoints, endpoint); len(endpoints) == 0 {
		m.endpoints.RemoveEntry(entry)
		m.endpointsPool.Put(endpoints)
	}
	endpoint.streams = streams
	if entry := m.endpoints.GetEntry(endpoint.streams); entry != nil {
		endpoints = entry.Value()
	} else {
		endpoints = m.endpointsPool.Get()
		m.endpoints.Put(endpoint.streams, endpoints)
	}
	endpoints[endpoint] = struct{}{}
}

func (m *MultiStreamManager) allocEndpoint() *endpoint {
	m.mu.Lock()
	defer m.mu.Unlock()
	entry := m.endpoints.GetFirstEntry()
	if entry == nil {
		return nil
	}
	streams, endpoints := entry.Key(), entry.Value()
	if streams >= m.serverMaxStreams {
		return nil
	}
	var endpoint *endpoint
	for e := range endpoints {
		endpoint = e
		break
	}
	m.changeEndpointStreams(entry, endpoint, endpoint.streams+1)
	return endpoint
}

func (m *MultiStreamManager) freeEndpoint(endpoint *endpoint) {
	if endpoint.streams == 0 {
		return
	}
	m.mu.Lock()
	defer m.mu.Unlock()
	entry := m.endpoints.GetEntry(endpoint.streams)
	if entry == nil {
		return
	}
	endpoints := entry.Value()
	if _, has := endpoints[endpoint]; !has {
		return
	}
	m.changeEndpointStreams(entry, endpoint, endpoint.streams-1)
}

func (m *MultiStreamManager) Alloc() Server {
	endpoint := m.allocEndpoint()
	if endpoint == nil {
		return nil
	}
	return endpoint.MultiStreamServer
}

func (m *MultiStreamManager) Free(s Server) {
	endpoint := m.serverEndpoint[s]
	if endpoint != nil {
		m.freeEndpoint(endpoint)
	}
}
