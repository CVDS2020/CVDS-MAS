package rtp

import (
	"net"
)

type Stream interface {
	Handler() Handler

	SetHandler(handler Handler) Stream

	SSRC() int64

	LocalAddr() net.Addr

	RemoteAddr() net.Addr

	SetRemoteAddr(addr net.Addr)

	Send(layer *Layer) error

	Close()

	Handler
}
