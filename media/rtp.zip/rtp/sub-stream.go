package rtp

import (
	"net"
	"sync"
	"sync/atomic"
)

type SubStream struct {
	server     *MultiStreamServer
	handler    atomic.Pointer[Handler]
	sockID     string
	sockSSRCID string
	ssrc       int64
	remoteAddr atomic.Pointer[net.UDPAddr]
	mu         sync.Mutex
}

func (s *SubStream) lock() {
	s.mu.Lock()
}

func (s *SubStream) unlock() {
	s.mu.Unlock()
}

func (s *SubStream) Server() Server {
	return s.server
}

func (s *SubStream) Handler() Handler {
	return *s.handler.Load()
}

func (s *SubStream) SetHandler(handler Handler) Stream {
	s.handler.Store(&handler)
	return s
}

func (s *SubStream) SSRC() int64 {
	return s.ssrc
}

func (s *SubStream) LocalAddr() net.Addr {
	return s.server.UDPAddr()
}

func (s *SubStream) RemoteAddr() net.Addr {
	return s.remoteAddr.Load()
}

func (s *SubStream) SetRemoteAddr(addr net.Addr) {
	var uAddr *net.UDPAddr
	switch rAddr := addr.(type) {
	case *net.TCPAddr:
		uAddr = (*net.UDPAddr)(rAddr)
	case *net.UDPAddr:
		uAddr = rAddr
	default:
		return
	}
	s.remoteAddr.Store(uAddr)
}

func (s *SubStream) Send(layer *Layer) error {
	if addr := s.remoteAddr.Load(); addr != nil {
		return s.server.SendTo(layer, addr)
	}
	return nil
}

func (s *SubStream) Close() {
	s.server.RemoveStream(s)
}

func (s *SubStream) HandleRTPPacket(stream Stream, packet *Packet) {
	s.lock()
	defer s.unlock()
	s.Handler().HandleRTPPacket(stream, packet)
}

func (s *SubStream) OnRTPChannelClose(stream Stream) {
	s.lock()
	defer s.unlock()
	s.Handler().OnRTPChannelClose(stream)
}
