package rtp

import (
	"fmt"
	"gitee.com/sy_183/common/uns"
	"net"
	"testing"
)

func TestLayerBuilderSize(t *testing.T) {
	conn, err := net.Dial("udp", "127.0.0.1:5902")
	if err != nil {
		t.Fatal(err)
	}
	layer := BuildLayer(&LayerConfig{
		Marker:         true,
		PayloadType:    96,
		SequenceNumber: 2,
		Timestamp:      3600,
		SSRC:           0x0,
		//CSRCList:          []uint32{0x1, 0x2, 0x3},
		ExtensionProfile: 10,
		//ExtensionContents: []uint32{0x12, 0x13, 0x14},
		PayloadContent: uns.StringToBytes("hello world"),
		//PaddingLength:     10,
	})
	if _, err = conn.Write(uns.StringToBytes("hello")); err != nil {
		t.Fatal(err)
	}
	fmt.Println(layer.String())
	if err = conn.Close(); err != nil {
		t.Fatal(err)
	}
}

func TestFlow(t *testing.T) {
	a := uint16(65535)
	b := uint16(65534)
	//a++
	fmt.Println(a)
	fmt.Println(int(b - a - 1))
}
